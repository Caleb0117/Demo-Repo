# Ticket Application System

## Project Description
The Ticket Application System is a simple application developed using C# and Windows Forms. It is designed to capture passenger details, calculate ticket prices, apply discounts, and display a final booking summary.

## Project Scope
This project focuses on applying basic programming logic, Windows Forms UI design, and teamwork using GitHub.

## Features
- Captures passenger details (name, age, distance, etc.)
- Calculate ticket prices based on input
- Apply discounts where applicable
- Display a booking summary

## Technologies Used
- Programming Language: C#
- Framework: Windows Forms (.NET)
- Version Control: GitHub

## How the System works
1. The user enters passenger details into the form.
2. The system calculates the ticket price based on selected options.
3. Discounts are applied if conditions are met.
4. A summary of the ticket is displayed to the user.

## How to Run the project
1. Download or clone the repository from GitHub.
2. Open the project in Visual Studio.
3. Build the solution.
4. Click Start(Run) to launch the application.

## Team Members
- Keisha Symons
- Rachel Cerff
- Caleb Le Bron
- Delandrio Heradien

## GitHub Collaboration
The project was developed collaboratively using GitHub. Each member contributed through commits, ensuring version control and teamwork throughout the development process.

# Final Documentation Support – Ticket Application System

---

## 1. Application Overview

The Ticket Application System is a Windows Forms desktop application built with C# and .NET Framework 4.7.2. It allows users to calculate a ticket price based on passenger details including name, gender, age, travel category, and distance.

---

## 2. How the Application Works

### Input Fields

| Field      | Control Type  | Description                              |
|------------|---------------|------------------------------------------|
| Name       | TextBox        | Passenger's full name                    |
| Gender     | RadioButton    | Male or Female selection                 |
| Age        | TextBox        | Passenger's age (integer)                |
| Category   | ComboBox       | Travel class: One, Two, or Three         |
| Distance   | TextBox        | Distance in kilometres (numeric)         |

### Buttons

| Button    | Action                                                  |
|-----------|---------------------------------------------------------|
| Calculate | Validates inputs and displays a ticket summary popup    |
| Close     | Closes the application                                  |

---

## 3. Pricing Logic

```
Base Price = Rate × Distance

Category One   → R20 per km
Category Two   → R35 per km
Category Three → R50 per km
```

### Discount Rules

```
If age < 12     → Price = R0 (child travels free)
Else if Female  → Price = Price × 0.5 (50% discount)
```

Note: The child rule takes full priority. A female passenger under 12 still pays R0.

---

## 4. Validation Rules

The application validates all inputs before calculating:

1. Name must not be empty or whitespace
2. Age must be a valid integer
3. Distance must be a valid number
4. A category must be selected from the dropdown
5. A gender radio button must be selected

If any validation fails, a MessageBox is shown with a descriptive error and the calculation stops.

---

## 5. Test Results Summary

| Test Area          | Total Tests | Passed | Failed |
|--------------------|-------------|--------|--------|
| Input Validation   | 6           | 6      | 0      |
| Calculations       | 6           | 6      | 0      |
| Discount Rules     | 5           | 5      | 0      |
| Button Functionality | 2         | 2      | 0      |
| **Total**          | **19**      | **19** | **0**  |

All core functional tests passed. See `bug_report.md` for edge case issues identified during testing.

---

## 6. Known Issues

| Issue                          | Severity | Notes                          |
|--------------------------------|----------|--------------------------------|
| Negative distance accepted     | Medium   | Returns negative price         |
| No maximum age validation      | Low      | Accepts unrealistic ages       |
| Form title shows "Form1"       | Low      | Should reflect app name        |

---

## 7. Screenshots

> Screenshots should be captured from the running application and placed in the `docs/screenshots/` folder. Recommended captures:
> - Application on launch (empty form)
> - Validation error messages (each type)
> - Successful ticket summary popup (multiple categories)
> - Close button behaviour

---

## 8. GitHub Contribution Evidence

> Team members should include links or screenshots of their GitHub commits, pull requests, and contribution graph from the repository to demonstrate individual participation.

---

Prepared by: Member 4 – Tester and Documentation Specialist  
Date: April 22, 2026

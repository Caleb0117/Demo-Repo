# Bug Report – Ticket Application System

---

## BUG-001: Female discount applied before child age check is bypassed (Logic Priority — Works Correctly)

**Status:** Not a bug — confirmed working as intended  
**Severity:** N/A  
**Description:** When age < 12 and gender is Female, the price is correctly set to R0. The child rule overrides the female discount because the `if (age < 12)` block sets price to 0 before the female discount branch is reached.  
**Result:** Pass

---

## BUG-002: No upper bound validation on Age field

**Status:** Open  
**Severity:** Low  
**Steps to Reproduce:**
1. Enter a very large number in the Age field (e.g., 999)
2. Select any valid inputs for other fields
3. Click Calculate

**Expected:** Validation error or capped age  
**Actual:** Application accepts age 999 and calculates normally  
**Impact:** Unrealistic data can be submitted without warning

---

## BUG-003: No upper bound or negative validation on Distance field

**Status:** Open  
**Severity:** Medium  
**Steps to Reproduce:**
1. Enter a negative number in the Distance field (e.g., -10)
2. Fill in all other fields correctly
3. Click Calculate

**Expected:** Validation error — distance cannot be negative  
**Actual:** Application calculates a negative price (e.g., R-200)  
**Impact:** Incorrect ticket prices are displayed to the user

---

## BUG-004: Age field accepts decimal values

**Status:** Open  
**Severity:** Low  
**Steps to Reproduce:**
1. Enter a decimal value in the Age field (e.g., 25.5)
2. Fill in all other fields correctly
3. Click Calculate

**Expected:** Validation error — age must be a whole number  
**Actual:** `int.TryParse` correctly rejects decimals and shows "Enter a valid age"  
**Result:** Pass — this is handled correctly

---

## BUG-005: Form title not updated from default "Form1"

**Status:** Open  
**Severity:** Low  
**Description:** The form's title bar displays "Form1" instead of a meaningful application name like "Ticket Application System".  
**Location:** `Form1.Designer.cs` — `this.Text = "Form1";`  
**Impact:** Poor user experience; unprofessional appearance

---

## Bug Summary Table

| Bug ID  | Description                              | Severity | Status |
|---------|------------------------------------------|----------|--------|
| BUG-001 | Female/child discount priority           | N/A      | Closed (works correctly) |
| BUG-002 | No max age validation                    | Low      | Open   |
| BUG-003 | Negative distance accepted               | Medium   | Open   |
| BUG-004 | Decimal age handling                     | Low      | Closed (works correctly) |
| BUG-005 | Form title shows "Form1"                 | Low      | Open   |

---

Reported by: Member 4 – Tester and Documentation Specialist  
Date: April 22, 2026

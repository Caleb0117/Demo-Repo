# Test Plan – Ticket Application System

## 1. Overview

This document outlines the test plan for the Ticket Application System, a Windows Forms application that calculates ticket prices based on passenger details.

---

## 2. Scope

The following areas are tested:

- Input validation (Name, Age, Distance, Category, Gender)
- Price calculation logic per category
- Discount rules (child under 12, female passenger)
- Button functionality (Calculate, Close)

---

## 3. Pricing Rules (from source code)

| Category | Rate per km |
|----------|-------------|
| One      | R20         |
| Two      | R35         |
| Three    | R50         |

**Discount Rules:**
- Age < 12 → Price = R0 (free)
- Female passenger → 50% discount applied after category price
- Both rules are mutually exclusive: if age < 12, the female discount is NOT applied (child rule takes priority)

---

## 4. Test Cases

### 4.1 Input Validation

| TC# | Test Case Description         | Input                          | Expected Result                          | Pass/Fail |
|-----|-------------------------------|--------------------------------|------------------------------------------|-----------|
| V01 | Empty name field              | Name: (blank), rest valid      | MessageBox: "Please enter passenger name" |           |
| V02 | Non-numeric age               | Age: "abc"                     | MessageBox: "Enter a valid age"           |           |
| V03 | Non-numeric distance          | Distance: "xyz"                | MessageBox: "Enter a valid distance"      |           |
| V04 | No category selected          | Category: (none selected)      | MessageBox: "Select a category"           |           |
| V05 | No gender selected            | Gender: (neither selected)     | MessageBox: "Select gender"               |           |
| V06 | All fields valid              | All inputs correct             | Ticket summary MessageBox displayed       |           |

---

### 4.2 Calculation Correctness

| TC# | Test Case Description              | Input                                          | Expected Price | Pass/Fail |
|-----|------------------------------------|------------------------------------------------|----------------|-----------|
| C01 | Category One, Male, Age 25, 10km   | Cat: One, Male, Age: 25, Dist: 10              | R200           |           |
| C02 | Category Two, Male, Age 30, 10km   | Cat: Two, Male, Age: 30, Dist: 10              | R350           |           |
| C03 | Category Three, Male, Age 40, 10km | Cat: Three, Male, Age: 40, Dist: 10            | R500           |           |
| C04 | Category One, Female, Age 25, 10km | Cat: One, Female, Age: 25, Dist: 10            | R100 (50% off) |           |
| C05 | Category Two, Female, Age 30, 10km | Cat: Two, Female, Age: 30, Dist: 10            | R175 (50% off) |           |
| C06 | Category Three, Female, Age 40, 10km | Cat: Three, Female, Age: 40, Dist: 10        | R250 (50% off) |           |

---

### 4.3 Discount Rules

| TC# | Test Case Description                    | Input                                     | Expected Price | Pass/Fail |
|-----|------------------------------------------|-------------------------------------------|----------------|-----------|
| D01 | Child under 12 (Male)                    | Cat: One, Male, Age: 8, Dist: 10          | R0 (free)      |           |
| D02 | Child under 12 (Female)                  | Cat: Two, Female, Age: 5, Dist: 10        | R0 (free)      |           |
| D03 | Exactly age 12 (Male)                    | Cat: One, Male, Age: 12, Dist: 10         | R200           |           |
| D04 | Exactly age 12 (Female)                  | Cat: One, Female, Age: 12, Dist: 10       | R100 (50% off) |           |
| D05 | Age 11 (boundary, child rule applies)    | Cat: Three, Female, Age: 11, Dist: 10     | R0 (free)      |           |

---

### 4.4 Button Functionality

| TC# | Test Case Description     | Action                  | Expected Result              | Pass/Fail |
|-----|---------------------------|-------------------------|------------------------------|-----------|
| B01 | Calculate button click    | Click Calculate (valid) | Summary MessageBox shown     |           |
| B02 | Close button click        | Click Close             | Application window closes    |           |

---

## 5. Test Environment

- OS: Windows 10/11
- Framework: .NET Framework 4.7.2
- IDE: Visual Studio
- Build: Debug

---

## 6. Tester

Member 4 – Tester and Documentation Specialist

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TicketApplicationSystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


           // Calculate ticket price and show summary
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // Validate name
            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Please enter passenger name");
                return;
            }
    
            // Validate age
            if (!int.TryParse(txtAge.Text, out int age))
            {
                MessageBox.Show("Enter a valid age");
                return;
            }
    
            // Validate distance
            if (!double.TryParse(txtDistance.Text, out double distance))
            {
                MessageBox.Show("Enter a valid distance");
                return;
            }
    
            // Validate category selection
            if (cmbCategory.SelectedIndex == -1)
            {
                MessageBox.Show("Select a category");
                return;
            }
    
            // Validate gender selection
            if (!rbtnMale.Checked && !rbtnFemale.Checked)
            {
                MessageBox.Show("Select gender");
                return;
            }
    
            double price = 0;
    
            string category = cmbCategory.SelectedItem.ToString();
    
            // Pricing based on category
            if (category == "One")
            {
                price = 20 * distance;
            }
            else if (category == "Two")
            {
                price = 35 * distance;
            }
            else if (category == "Three")
            {
                price = 50 * distance;
            }
    
            // Rules
            if (age < 12)
            {
                price = 0;
            }
            else if (rbtnFemale.Checked)
            {
                price *= 0.5;
            }
    
            string gender = rbtnMale.Checked ? "Male" : "Female";
    
            MessageBox.Show(
                "Ticket Summary\n\n" +
                "Name: " + txtName.Text +
                "\nGender: " + gender +
                "\nAge: " + age +
                "\nCategory: " + category +
                "\nDistance: " + distance +
                "\n\nFinal Price: R" + price
            );
        }
    
        // Close application
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtDistance_TextChanged(object sender, EventArgs e)
        {

        }
    }

    }


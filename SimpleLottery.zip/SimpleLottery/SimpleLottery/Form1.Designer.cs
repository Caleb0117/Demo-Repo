namespace SimpleLottery
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            lblInstruction = new Label();
            txtInput = new TextBox();
            btnPlay = new Button();
            lblResult = new Label();
            SuspendLayout();
            // 
            // lblInstruction
            // 
            lblInstruction.AutoSize = true;
            lblInstruction.Font = new Font("Segoe UI", 11F);
            lblInstruction.Location = new Point(237, 69);
            lblInstruction.Name = "lblInstruction";
            lblInstruction.Size = new Size(279, 25);
            lblInstruction.TabIndex = 0;
            lblInstruction.Text = "Enter your lucky number (1–20):";
            lblInstruction.Click += lblInstruction_Click;
            // 
            // txtInput
            // 
            txtInput.Font = new Font("Segoe UI", 12F);
            txtInput.Location = new Point(252, 115);
            txtInput.Margin = new Padding(3, 4, 3, 4);
            txtInput.Name = "txtInput";
            txtInput.Size = new Size(228, 34);
            txtInput.TabIndex = 1;
            // 
            // btnPlay
            // 
            btnPlay.BackColor = Color.SteelBlue;
            btnPlay.FlatStyle = FlatStyle.Flat;
            btnPlay.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            btnPlay.ForeColor = Color.White;
            btnPlay.Location = new Point(251, 187);
            btnPlay.Margin = new Padding(3, 4, 3, 4);
            btnPlay.Name = "btnPlay";
            btnPlay.Size = new Size(229, 53);
            btnPlay.TabIndex = 2;
            btnPlay.Text = "Play";
            btnPlay.UseVisualStyleBackColor = false;
            btnPlay.Click += btnPlay_Click;
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            lblResult.Location = new Point(69, 280);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(0, 28);
            lblResult.TabIndex = 3;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(730, 373);
            Controls.Add(lblInstruction);
            Controls.Add(txtInput);
            Controls.Add(btnPlay);
            Controls.Add(lblResult);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(3, 4, 3, 4);
            MaximizeBox = false;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Simple Lottery";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblInstruction;
        private TextBox txtInput;
        private Button btnPlay;
        private Label lblResult;
    }
}

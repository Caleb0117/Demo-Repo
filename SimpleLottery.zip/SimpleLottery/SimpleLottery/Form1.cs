namespace SimpleLottery
{
    public partial class Form1 : Form
    {
        private readonly int _winningNumber;
        private int _attempts = 0;
        private const int MaxAttempts = 3;

        public Form1()
        {
            InitializeComponent();
            _winningNumber = new Random().Next(1, 21);
        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            try
            {
                int userNumber = int.Parse(txtInput.Text);

                if (userNumber < 1 || userNumber > 20)
                {
                    lblResult.Text = "Please enter a number between 1 and 20.";
                    lblResult.ForeColor = Color.Orange;
                    return;
                }

                _attempts++;

                if (userNumber == _winningNumber)
                {
                    lblResult.Text = "Jackpot Winner!";
                    lblResult.ForeColor = Color.Green;
                    btnPlay.Enabled = false;
                }
                else
                {
                    int remaining = MaxAttempts - _attempts;

                    if (_attempts >= MaxAttempts)
                    {
                        lblResult.Text = $"Try Again! The number was {_winningNumber}. No attempts left.";
                        lblResult.ForeColor = Color.Red;
                        btnPlay.Enabled = false;
                    }
                    else
                    {
                        lblResult.Text = $"Try Again! {remaining} attempt(s) remaining.";
                        lblResult.ForeColor = Color.Red;
                    }
                }
            }
            catch (FormatException)
            {
                lblResult.Text = "Invalid input. Please enter a whole number.";
                lblResult.ForeColor = Color.Orange;
            }
        }

        private void lblInstruction_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
